import React, { useState, useEffect } from 'react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { useToast } from '../hooks/use-toast';
import { 
  ClipboardCheck, 
  Workflow, 
  Building2, 
  Zap, 
  Target, 
  Lock, 
  TrendingUp,
  Mail,
  Linkedin,
  Calendar,
  CheckCircle2,
  ArrowRight,
  Briefcase,
  MessageSquare,
  Share2,
  Users,
  FileText,
  Rocket,
  CalendarCheck,
  FolderOpen,
  Search,
  HardDrive,
  LayoutGrid,
  Headphones,
  Sparkles,
  Shield,
  BarChart3,
  Layers
} from 'lucide-react';

const Home = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "We'll get back to you within 24 hours.",
    });
    setFormData({ name: '', email: '', message: '' });
  };

  const scrollToSection = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-lg border-b border-gray-100 shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-slate-900 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-xl">E</span>
              </div>
              <span className="text-2xl font-bold text-slate-900">Exequa</span>
            </div>

            <nav className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('about')} className="text-slate-700 hover:text-cyan-600 transition-colors font-medium">
                About
              </button>
              <button onClick={() => scrollToSection('services')} className="text-slate-700 hover:text-cyan-600 transition-colors font-medium">
                Services
              </button>
              <button onClick={() => scrollToSection('why-choose')} className="text-slate-700 hover:text-cyan-600 transition-colors font-medium">
                Why Us
              </button>
              <button onClick={() => scrollToSection('contact')} className="text-slate-700 hover:text-cyan-600 transition-colors font-medium">
                Contact
              </button>
            </nav>

            <Button 
              onClick={() => scrollToSection('contact')}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-6 py-2 rounded-xl transition-all hover:scale-105 shadow-lg font-semibold"
            >
              Book a Consultation
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1497215728101-856f4ea42174"
            alt="Modern Virtual Office"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-blue-900/90 to-slate-900/95"></div>
        </div>

        <div className={`container mx-auto px-6 z-10 transform transition-all duration-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'}`}>
          <div className="max-w-4xl">
            <div className="inline-block px-4 py-2 bg-white/10 backdrop-blur-md rounded-full border border-cyan-400/30 mb-6">
              <p className="text-cyan-400 text-sm font-medium flex items-center gap-2">
                <Sparkles className="h-4 w-4" />
                Precision in Every Process
              </p>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Where Precision Meets <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Accountability</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-12 leading-relaxed max-w-2xl">
              Executive support designed for growing businesses. We bring structure to operations, clarity to processes, and precision to execution.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => scrollToSection('contact')}
                className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 py-6 text-lg rounded-xl transition-all hover:scale-105 hover:shadow-2xl font-semibold"
              >
                Book a Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                onClick={() => scrollToSection('services')}
                variant="outline"
                className="bg-white/10 backdrop-blur-sm border-cyan-400/30 text-white hover:bg-white/20 px-8 py-6 text-lg rounded-xl transition-all font-semibold"
              >
                Explore Services
              </Button>
            </div>
          </div>
        </div>

        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
          <div className="w-6 h-10 border-2 border-cyan-400/40 rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-cyan-400/70 rounded-full"></div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-cyan-100 to-blue-100 rounded-full blur-3xl opacity-20"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-blue-100 to-cyan-100 rounded-full blur-3xl opacity-20"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-block px-4 py-2 bg-gradient-to-r from-cyan-100 to-blue-100 rounded-full mb-4">
              <p className="text-blue-700 text-sm font-semibold">ABOUT EXEQUA</p>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Modern Executive Support Built for <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">Ambition</span>
            </h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-blue-600 via-cyan-500 to-orange-500 mx-auto mb-8 rounded-full"></div>
            <p className="text-lg text-slate-600 leading-relaxed mb-6">
              Exequa is a modern executive and operational support company built to serve ambitious businesses worldwide. We specialize in delivering structured systems, reliable coordination, and detail-focused execution across administrative, operational, and growth functions.
            </p>
            <div className="bg-gradient-to-r from-blue-50 via-cyan-50 to-slate-50 rounded-2xl p-8 border border-blue-100">
              <p className="text-2xl font-bold text-slate-900 mb-2">Our Philosophy</p>
              <p className="text-lg text-slate-700 italic">Strong systems create scalable success.</p>
              <p className="text-slate-600 mt-4">With precision in every process, we ensure efficiency, accountability, and measurable impact.</p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mt-16">
            <div className="text-center p-6 bg-white rounded-2xl shadow-lg border border-blue-100 hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Target className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Our Mission</h3>
              <p className="text-slate-600">Delivering structured systems and reliable coordination</p>
            </div>

            <div className="text-center p-6 bg-white rounded-2xl shadow-lg border border-orange-100 hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Users className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Global Reach</h3>
              <p className="text-slate-600">Serving ambitious businesses worldwide</p>
            </div>

            <div className="text-center p-6 bg-white rounded-2xl shadow-lg border border-cyan-100 hover:shadow-xl transition-shadow">
              <div className="w-14 h-14 bg-gradient-to-br from-cyan-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Sparkles className="h-7 w-7 text-white" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">Our Standard</h3>
              <p className="text-slate-600">Excellence in every detail, every process</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-gradient-to-b from-slate-50 to-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-gradient-to-r from-orange-100 to-cyan-100 rounded-full mb-4">
              <p className="text-orange-600 text-sm font-semibold">OUR SERVICES</p>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              Comprehensive Solutions for <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">Operational Excellence</span>
            </h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-orange-600 via-cyan-500 to-blue-500 mx-auto mb-6 rounded-full"></div>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              From executive coordination to growth initiatives, we deliver structured support across every business function
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
            {[
              { icon: Briefcase, title: 'Executive Assistance', desc: 'High-level support for executives including strategic coordination and priority management', gradient: 'from-blue-500 to-cyan-500' },
              { icon: Mail, title: 'Email Management', desc: 'Professional inbox organization, prioritization, and response management', gradient: 'from-cyan-500 to-teal-500' },
              { icon: Share2, title: 'Social Media Management', desc: 'Content creation, scheduling, and engagement across all platforms', gradient: 'from-orange-500 to-amber-500' },
              { icon: TrendingUp, title: 'Lead Generation', desc: 'Strategic prospecting and qualified lead identification for growth', gradient: 'from-blue-600 to-indigo-600' },
              { icon: ClipboardCheck, title: 'Administrative Work', desc: 'Comprehensive administrative support to keep operations running smoothly', gradient: 'from-indigo-500 to-blue-500' },
              { icon: Rocket, title: 'Business Development', desc: 'Strategic growth initiatives and partnership development support', gradient: 'from-cyan-500 to-blue-500' },
              { icon: CalendarCheck, title: 'Calendar Management', desc: 'Efficient scheduling, coordination, and meeting optimization', gradient: 'from-orange-500 to-red-500' },
              { icon: FolderOpen, title: 'File Management', desc: 'Document organization, version control, and archival systems', gradient: 'from-teal-500 to-cyan-500' },
              { icon: Search, title: 'Web Research', desc: 'In-depth market research, competitor analysis, and data gathering', gradient: 'from-blue-500 to-purple-500' },
              { icon: HardDrive, title: 'Drive Management', desc: 'Cloud storage organization and team collaboration setup', gradient: 'from-cyan-600 to-blue-600' },
              { icon: LayoutGrid, title: 'Project/CRM Management', desc: 'End-to-end project tracking and customer relationship systems', gradient: 'from-orange-600 to-orange-700' },
              { icon: Headphones, title: 'All Backend Support', desc: 'Complete operational support tailored to your unique business needs', gradient: 'from-blue-600 to-cyan-600' },
            ].map((service, idx) => (
              <Card key={idx} className="group hover:shadow-2xl transition-all duration-300 border-2 border-transparent hover:border-cyan-300 hover:-translate-y-1 bg-white">
                <CardContent className="p-6">
                  <div className={`w-14 h-14 bg-gradient-to-br ${service.gradient} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <service.icon className="h-7 w-7 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{service.title}</h3>
                  <p className="text-slate-600 leading-relaxed">{service.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <p className="text-lg text-slate-700 font-semibold italic">
              We operate as an extension of your team — not just a service provider.
            </p>
          </div>
        </div>
      </section>

      {/* Why Choose Section */}
      <section id="why-choose" className="py-24 bg-gradient-to-br from-blue-50 via-cyan-50 to-slate-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-white rounded-full mb-4 shadow-md">
              <p className="text-blue-600 text-sm font-semibold">WHY CHOOSE EXEQUA</p>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              The <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">Exequa</span> Advantage
            </h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-blue-600 via-cyan-500 to-orange-500 mx-auto mb-6 rounded-full"></div>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              We don't just execute tasks—we build systems that transform how you operate
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {[
              { icon: Sparkles, title: 'Precision in Every Process', desc: 'Meticulous attention to detail ensures flawless execution across all operational touchpoints', gradient: 'from-blue-500 to-cyan-500' },
              { icon: Layers, title: 'Structured & Reliable Systems', desc: 'Built on proven frameworks that deliver consistent results and measurable performance', gradient: 'from-orange-500 to-amber-500' },
              { icon: Shield, title: 'Confidential & Professional', desc: 'Discretion and integrity are at the core of every client engagement', gradient: 'from-cyan-500 to-teal-500' },
              { icon: TrendingUp, title: 'Scalable Solutions', desc: 'Flexible systems designed to expand alongside your business objectives', gradient: 'from-blue-600 to-indigo-600' },
              { icon: Target, title: 'Detail-Oriented Approach', desc: 'Nothing escapes our scrutiny—from small tasks to strategic initiatives', gradient: 'from-indigo-500 to-blue-500' },
              { icon: BarChart3, title: 'Performance-Driven Support', desc: 'Results-focused methodology that prioritizes outcomes and efficiency', gradient: 'from-orange-600 to-red-600' },
            ].map((feature, idx) => (
              <div key={idx} className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 border-2 border-transparent hover:border-cyan-300 hover:-translate-y-2">
                <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg`}>
                  <feature.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How We Drive Results */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-blue-50/30 to-cyan-50/30"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full mb-4">
              <p className="text-blue-600 text-sm font-semibold">OUR APPROACH</p>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">
              How We Drive <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-600">Results</span>
            </h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-blue-600 via-cyan-500 to-orange-500 mx-auto mb-6 rounded-full"></div>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              A proven three-phase methodology that transforms operational chaos into structured excellence
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-3 gap-8">
              <div className="relative">
                <div className="bg-gradient-to-br from-blue-600 to-cyan-600 rounded-2xl p-8 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="text-6xl font-bold mb-4 opacity-50">01</div>
                  <h3 className="text-2xl font-bold mb-4">Assess</h3>
                  <p className="text-white/90 leading-relaxed">
                    We understand your workflow gaps and operational challenges
                  </p>
                </div>
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                  <ArrowRight className="h-8 w-8 text-cyan-400" />
                </div>
              </div>

              <div className="relative">
                <div className="bg-gradient-to-br from-cyan-600 to-blue-600 rounded-2xl p-8 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="text-6xl font-bold mb-4 opacity-50">02</div>
                  <h3 className="text-2xl font-bold mb-4">Structure</h3>
                  <p className="text-white/90 leading-relaxed">
                    We design systems tailored to your business objectives
                  </p>
                </div>
                <div className="hidden md:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                  <ArrowRight className="h-8 w-8 text-orange-400" />
                </div>
              </div>

              <div>
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl p-8 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2">
                  <div className="text-6xl font-bold mb-4 opacity-50">03</div>
                  <h3 className="text-2xl font-bold mb-4">Execute</h3>
                  <p className="text-white/90 leading-relaxed">
                    We deliver with precision, consistency, and measurable results
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-24 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 relative overflow-hidden">
        <div className="absolute top-20 right-10 w-32 h-32 bg-cyan-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-10 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl animate-pulse delay-75"></div>
        <div className="absolute top-40 left-1/3 w-24 h-24 bg-orange-500/10 rounded-full blur-2xl animate-pulse delay-150"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <div className="inline-block px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-4 border border-cyan-400/30">
              <p className="text-cyan-400 text-sm font-semibold">GET IN TOUCH</p>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
              Let's Bring Structure to Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Success</span>
            </h2>
            <div className="w-24 h-1.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-orange-500 mx-auto mb-6 rounded-full"></div>
            <p className="text-xl text-gray-300 max-w-2xl mx-auto">
              Partner with Exequa today and experience operational excellence backed by precision
            </p>
          </div>

          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
            <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
              <h3 className="text-2xl font-bold text-white mb-6">Book Your Consultation</h3>
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <Input
                    type="text"
                    name="name"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/60 focus:border-cyan-400 focus:ring-cyan-400 rounded-xl"
                    required
                  />
                </div>
                <div>
                  <Input
                    type="email"
                    name="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/60 focus:border-cyan-400 focus:ring-cyan-400 rounded-xl"
                    required
                  />
                </div>
                <div>
                  <Textarea
                    name="message"
                    placeholder="Tell us about your needs..."
                    value={formData.message}
                    onChange={handleInputChange}
                    rows={4}
                    className="bg-white/20 border-white/30 text-white placeholder:text-white/60 focus:border-cyan-400 focus:ring-cyan-400 resize-none rounded-xl"
                    required
                  />
                </div>
                <Button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white py-6 rounded-xl transition-all hover:scale-105 font-bold text-lg shadow-xl"
                >
                  Send Message
                  <CheckCircle2 className="ml-2 h-5 w-5" />
                </Button>
              </form>
            </div>

            <div className="space-y-6">
              <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
                <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-500 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-4">Schedule a Call</h3>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  Book a time that works for you and let's discuss how we can help streamline your operations
                </p>
                <Button 
                  onClick={() => window.open('https://calendly.com/yourlink', '_blank')}
                  className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-6 rounded-xl transition-all hover:scale-105 font-bold text-lg shadow-xl"
                >
                  Book on Calendly
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </div>

              <div className="bg-white/10 backdrop-blur-xl rounded-3xl p-8 border border-white/20 shadow-2xl">
                <div className="space-y-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-cyan-600/50 rounded-xl flex items-center justify-center">
                      <Mail className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Email</p>
                      <p className="text-white font-semibold">contact@exequa.com</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-600/50 rounded-xl flex items-center justify-center">
                      <Users className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Location</p>
                      <p className="text-white font-semibold">Remote Global Support</p>
                    </div>
                  </div>
                  <div className="pt-4 border-t border-white/20">
                    <div className="flex items-center space-x-3 text-gray-300 text-sm">
                      <Lock className="h-5 w-5" />
                      <p>Your business information is treated with the highest level of discretion</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 py-12 border-t border-slate-800">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-3 mb-6 md:mb-0">
              <div className="w-8 h-8 bg-slate-800 rounded-lg flex items-center justify-center shadow-lg">
                <span className="text-white font-bold">E</span>
              </div>
              <span className="text-xl font-bold text-white">Exequa</span>
            </div>

            <div className="flex items-center space-x-6 mb-6 md:mb-0">
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-cyan-400 transition-colors"
              >
                <Linkedin className="h-6 w-6" />
              </a>
              <a 
                href="mailto:contact@exequa.com"
                className="text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Mail className="h-6 w-6" />
              </a>
            </div>

            <p className="text-gray-400 text-sm">
              © 2024 Exequa. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;
